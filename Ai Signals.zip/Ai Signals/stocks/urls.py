from django.urls import path
from .views import home, fetch_stock_data


urlpatterns = [
    path("", home, name="home"),
    path("fetch_stock_data/", fetch_stock_data, name="fetch_stock_data"),
]
