import yfinance as yf
from django.http import JsonResponse
from django.shortcuts import render
import numpy as np

def home(request):
    return render(request, 'stocks/home.html')

def fetch_stock_data(request):
    stock_symbols = [
        "AAPL", "GOOGL", "TSLA", "MSFT", "AMZN", "NVDA", "META", "NFLX", "BRK-A", "V",
        "PYPL", "ADBE", "INTC", "CSCO", "AMD", "IBM", "BA", "JPM", "GS", "DIS",
        "PEP", "KO", "MCD", "SBUX", "NKE", "WMT", "COST", "TGT", "HD", "LOW",
        "XOM", "CVX", "BP", "TSM", "BABA", "ORCL", "CRM", "UBER", "LYFT", "SQ"
    ]

    stock_data = []
    
    for symbol in stock_symbols:
        try:
            stock = yf.Ticker(symbol)
            data = stock.history(period="7d")  # Fetch last 7 days of data
            
            if data.empty:
                continue

            # Get last closing prices
            close_prices = data["Close"].values

            # Calculate 3-day and 7-day SMA
            short_sma = np.mean(close_prices[-3:])  # Short-term Moving Average (3 days)
            long_sma = np.mean(close_prices)       # Long-term Moving Average (7 days)

            # Generate Buy/Sell signals
            signal = "Hold"
            if short_sma > long_sma:
                signal = "Buy"
            elif short_sma < long_sma:
                signal = "Sell"

            stock_data.append({
                "symbol": symbol,
                "open": round(data["Open"].iloc[-1], 2),
                "close": round(data["Close"].iloc[-1], 2),
                "high": round(data["High"].iloc[-1], 2),
                "low": round(data["Low"].iloc[-1], 2),
                "volume": int(data["Volume"].iloc[-1]),
                "current_price": round(data["Close"].iloc[-1], 2),
                "signal": signal  # Add Buy/Sell signal
            })

        except Exception as e:
            print(f"Error fetching {symbol}: {e}")

    return JsonResponse({"stocks": stock_data})
