from django.contrib import admin
from django.urls import path, include
from stocks.views import home  # ✅ Import the home view

urlpatterns = [
    path('', home),  # ✅ Add home page at root "/"
    path('admin/', admin.site.urls),
    path('stocks/', include('stocks.urls')),
]